python plot_expert_weights.py --input raw_data/session_1.json --csv_path data/session_1.csv --png_path plots/session_1.png --title "Session 1, M=2, n=40"
python plot_expert_weights.py --input raw_data/session_2.json --csv_path data/session_2.csv --png_path plots/session_2.png --title "Session 2, M=12, n=100" --dashed 1
python plot_expert_weights.py --input raw_data/session_3.json --csv_path data/session_3.csv --png_path plots/session_3.png --title "Session 3, M=3, n=45"

